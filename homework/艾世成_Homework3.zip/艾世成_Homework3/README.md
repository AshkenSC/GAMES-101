1. 提交格式正确，包括所有需要的文件。代码可以正常编译、执行。

2. 完成了参数插值功能，插值颜色、法向量、纹理坐标、shading position并传递给fragment_shader_payload。

3. 完成了Blinn-phong反射模型，实现了phong_fragment_shader中的环境光、漫反射、镜面反射。

4. 完成了Texture mapping，实现了texture_fragment_shader，可以正确显示纹理。